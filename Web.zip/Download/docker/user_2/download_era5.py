import os
import cdsapi

year_ini = 1940
year_fin = 2024
variable = "temperature"
dataset = "reanalysis-era5-pressure-levels"
pressure_level = 1

periodo = (int(year_ini), int(year_fin))

dir = f"/data/{dataset}/{variable}/{pressure_level}/"
anno = periodo[0]

while anno <= periodo[1]:
    filename = os.path.join(dir, f"{anno}_{variable}.nc")
    target = filename
    request = {
        "product_type": ["reanalysis"],
        "variable": [variable],
        "year": [str(anno)],
        "month": ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'],
        "day": ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31'],
        "time": ['00:00', '01:00', '02:00', '03:00', '04:00', '05:00', '06:00', '07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00'],
        "pressure_level": [str(pressure_level)],
        "data_format": "netcdf",
        "download_format": "unarchived",
        "area": [40.75, -3.75, 40.25, -3.25]
    }
    anno += 1
    client = cdsapi.Client(
        url='https://cds.climate.copernicus.eu/api',
        key='24dab589-b5d6-42da-a9f5-20e62a449522'
    )
    client.retrieve(dataset, request, target)
